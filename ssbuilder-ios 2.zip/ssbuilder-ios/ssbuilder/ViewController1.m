//
//  ViewController1.m
//  ssbuilder
//
//  Created by Ruiheng Wang on 10/28/15.
//  Copyright © 2015 Ruiheng Wang. All rights reserved.
//

#import "ViewController1.h"
#import "MyTableViewController.h"

@interface ViewController1 ()
//@property (weak, nonatomic) IBOutlet UILabel *titleLabel1;
//@synthesize NSMutableArray *titleList;
@property MyTableViewController *myTVC;


@end

@implementation ViewController1
@synthesize titleList;
//@synthesize jsonObject1;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //self.myController.title = self.titleList;
    //SLog(self.myController.titles);
    //NSLog(self.myController.)
    self.myTVC = [[MyTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
    //UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:self.myTVC];

}



-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:true];
   // NSLog(@"lol");
    NSLog(@"my array: %@", self.titleList);
    [self.myTVC populateDataWithFirstItems:self.titleList];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:self.myTVC];
    self.myTVC.title = @"story List";
    [self presentViewController:navController animated:YES completion:nil];
}



- (IBAction)returnButton:(id)sender {
     [self dismissViewControllerAnimated:YES completion:nil];

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
