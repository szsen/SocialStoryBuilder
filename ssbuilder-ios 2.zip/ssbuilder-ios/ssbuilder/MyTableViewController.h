//
//  MyTableViewController.h
//  ssbuilder
//
//  Created by Ruiheng Wang on 10/14/15.
//  Copyright © 2015 Ruiheng Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewController : UITableViewController
@property (nonatomic, strong) id jsonObject1;
//@property (nonatomic, strong) NSString* titles;

- (void) populateDataWithFirstItems: (NSMutableArray *) firstItems;

@end
