//
//  MyTableViewController.m
//  ssbuilder
//
//  Created by Ruiheng Wang on 10/14/15.
//  Copyright © 2015 Ruiheng Wang. All rights reserved.
//

#import "MyTableViewController.h"
#import "ViewController1.h"

@interface MyTableViewController ()

@property NSMutableArray *nameList;
@property NSMutableArray *titleMArray;
//@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
//@property (weak, nonatomic) IBOutlet UILabel *captionLabel;
//@property (weak, nonatomic) IBOutlet UIImageView *storyImage;
//@property NSString *titles;

@end


@implementation MyTableViewController
@synthesize jsonObject1;

- (void)viewDidLoad {
    [super viewDidLoad];
    //NSLog(self.nameList);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    ///Dispose of any resources that can be recreated.
}

- (void) populateDataWithFirstItems: (NSMutableArray *) firstItems{

    self.nameList = firstItems;
     NSLog(@"my arraylol: %@", self.nameList);

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.

    //switch (section) {
        //case 0:
            return self.nameList.count - 1;
            //break;
       // default:
           // break;
    //}

    //return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];

    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    }

    // Configure the cell...

//    switch (indexPath.section) {
//        case 0:{
//            NSArray *item = [self.nameList objectAtIndex:indexPath.row];
//            NSString *mainText = [item objectAtIndex:0];// i.e. "Juice"
//            cell.textLabel.text = mainText;
//            break;
//        }
//        default:
//            break;
//   }
    cell.textLabel.text = self.nameList[indexPath.row];

   return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    ViewController1 *myViewController1 = [[ViewController1 alloc] init];
    for (int i = 0; i < [self.nameList count] ; i++) {
        if ([[self.nameList objectAtIndex:indexPath.row] isEqual:self.nameList[i]]) {
            //NSLog([NSString stringWithFormat:@"%@", self.nameList[i]]);
            NSString *nameUrl = self.nameList[i];
            nameUrl = [nameUrl stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
            //NSLog(nameUrl);
            NSString *url = @"http://localhost:3000/api/student-story/";
            NSString *myUrlString =[url stringByAppendingString: nameUrl];
            NSURL *myUrl = [NSURL URLWithString:myUrlString];
            NSURLSession *urlSession = [NSURLSession sharedSession];
            [[urlSession dataTaskWithURL:myUrl completionHandler:^(NSData *datastory, NSURLResponse *response, NSError *error) {
                if ([datastory length] >0 && error == nil){
                    //process the JSON response
                    //use the main queue so that we can interact with the screen
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self parseResponseStory:datastory];
                        myViewController1.titleList = self.titleMArray;
                    });
                }
                else if ([datastory length] == 0 && error == nil){
                   NSLog(@"Empty Response, not sure why?");
                }
                else if (error != nil){
                   NSLog(@"Not again, what is the error = %@", error);
            }
            }]resume];
            //ViewController1 *myViewController1 = [[ViewController1 alloc] init];
            //myViewController1.titleList = self.titleMArray;
            [self presentViewController:myViewController1 animated:YES completion:nil];
        }
        
    }
    self.titleMArray = [[NSMutableArray alloc] init];
    
}

- (void) parseResponseStory: (NSData *) datastory{
    NSString *myDataStory = [[NSString alloc] initWithData:datastory encoding:NSUTF8StringEncoding];
    NSLog(@"JSON data = %@", myDataStory);
    NSError *error = nil;
    //parsing the Json response
    jsonObject1 =[NSJSONSerialization JSONObjectWithData:datastory options:NSJSONReadingAllowFragments error:&error];
    if(jsonObject1 != nil && error ==nil){
        NSLog(@"successfully deserialized...");
    }
    //self.titleLabel.text = [jsonObject1 objectForKey:@"title"];
    //self.captionLabel.text = [jsonObject1 objectForKey:@"description"];
    //self.storyImage.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[jsonObject1 objectForKey:@"url"]]]];
    NSDictionary *dict = [jsonObject1 objectAtIndex:0];
    //NSString *titles = @"";
    //self.titles = @"";
    for(int i = 0; i < [jsonObject1 count]; i++) {
        dict = [jsonObject1 objectAtIndex:i];
        NSString *curr = [dict objectForKeyedSubscript:@"title"];
        //self.titles = [[self.titles stringByAppendingString:curr] stringByAppendingString:@" "];
        [self.titleMArray addObject:curr];
        NSLog(@"added %@", curr);
    }
    //NSArray *titleArray = [self.titles componentsSeparatedByString:@" "];
    //[self.titleMArray addObjectsFromArray:titleArray];
    //NSLog(self.titleMArray[1]);
    NSLog(@"my array: %@", self.titleMArray);
    //NSLog(self.titleMArray[1]);
//    ViewController1 *myViewController1 = [[ViewController1 alloc] init];
//    [self presentViewController:myViewController1 animated:YES completion:nil];
    //self.titleLabel.text = titles;
    
}



@end

