//
//  MyTableViewController1.h
//  ssbuilder
//
//  Created by Ruiheng Wang on 11/3/15.
//  Copyright © 2015 Ruiheng Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewController1 : UIViewController
- (void) populateDataWithFirstItems: (NSMutableArray *) firstItems;

@end
